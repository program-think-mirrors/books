//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LISLab.RC
//
#define IDD_LISLAB                      1
#define IDC_WNDFOCUS                    100
#define IDC_WNDACTIVE                   101
#define IDC_WNDFOREGROUND               102
#define IDI_LISLAB                      102
#define IDC_WNDCAPTURE                  103
#define IDC_CLIPCURSOR                  104
#define IDC_WNDFUNC                     105
#define IDC_FUNCSTART                   106
#define IDC_DELAY                       107
#define IDC_WNDS                        110
#define IDC_THREADATTACH                111
#define IDC_THREADDETACH                112
#define IDC_MOUSEMSGS                   113
#define IDC_SETCLIPRECT                 114
#define IDC_REMOVECLIPRECT              115
#define IDC_HIDECURSOR                  116
#define IDC_SHOWCURSOR                  117
#define IDC_EVENTPENDING                118
#define IDC_PREVWND                     119
#define IDC_INFINITELOOP                120

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
